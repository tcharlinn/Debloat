# TCL TV Debloat — Android (celular controlador)

Aplicativo Android nativo em Kotlin para conectar a uma TCL Android TV / Google TV pela rede Wi‑Fi usando ADB. O telefone é o cliente ADB; a TV continua sendo o dispositivo gerenciado.

## O que está incluído

- Conexão ADB TCP (firmwares que expõem `IP:5555` ou outra porta configurada).
- Pareamento ADB Wireless Debugging por código (Android 11+; TVs em geral exigem Android/Google TV compatível; a opção de depuração sem fio deve estar habilitada).
- Diagnóstico de fabricante, modelo, Android/SDK, build, patch, resolução, densidade, memória, rede, USB host e pacotes desativados.
- Backup de inventário de pacotes, propriedades, configurações global/secure/system, Wi‑Fi e conectividade em ZIP no armazenamento privado do app.
- Classificação heurística de pacotes; inspeção com `dumpsys package`.
- Desativação individual com confirmação, espera de 15 segundos, `sync` e conferência por `pm list packages -d`.
- Reativação individual e restauração local dos pacotes que o próprio app registrou como desativados.
- Documentação de segurança, limites e roteiro de verificação.

## Limitações importantes desta versão

1. Não há como garantir compatibilidade com todos os firmwares TCL. O ADB pode estar ausente, bloqueado ou usar portas dinâmicas.
2. O pareamento TLS depende da implementação Kadb e do suporte de TLS/Conscrypt do Android hospedeiro. Teste em seu aparelho antes de qualquer alteração.
3. O backup é de inventário e configurações consultáveis, **não** é imagem de firmware, backup de dados privados nem snapshot restaurável da TV.
4. A classificação é apenas uma pista. Não desative automaticamente nenhum pacote; confirme uso e função na própria TV.
5. A lista protegida é conservadora, mas nenhum filtro por nome consegue conhecer todos os componentes OEM críticos. Nunca desative pacote desconhecido sem pesquisa e plano de recuperação.
6. O app ainda não implementa captura/pull automático de screenshots da TV, descoberta mDNS automática, editor de launcher Apple TV, nem restauração de rede/valores de settings. Esses itens precisam de teste e implementação adicional antes de chamar o produto de equivalente integral ao repositório CleanYourTV.
7. Não há APK pré-compilado neste pacote: gere-o com Android Studio/Gradle conforme abaixo. Não foi possível testar em uma TV física nesta entrega.

## Requisitos para compilar

- Android Studio recente (Giraffe ou mais novo) com JDK 17.
- Android SDK Platform 35.
- Internet na primeira sincronização Gradle para baixar plugins e `com.flyfishxu:kadb:2.1.5`.

Abra a pasta `TCL_TV_Debloat_Android` no Android Studio e aguarde a sincronização. Em seguida: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

No terminal, com Gradle instalado: `gradle assembleDebug`.

## Instalação

Instale o APK no telefone Android. Conecte o telefone e a TV à mesma rede Wi‑Fi. Na TV, habilite Developer options e ADB/Wireless debugging. Para Android 11+, escolha “Pair device with pairing code”, informe IP e porta de pareamento no app e o código temporário. Depois use o IP e a porta de conexão exibidos na tela principal de Wireless debugging para conectar.

Em firmwares antigos com ADB TCP, informe `IP:5555` (ou porta efetiva). A TV pode exibir uma confirmação de autorização RSA; aceite apenas o telefone que você está usando.

## Uso seguro recomendado

1. Conecte e rode o diagnóstico.
2. Crie e copie o ZIP de backup para outro local.
3. Liste os pacotes e inspecione cada candidato via `dumpsys`.
4. Antes de mexer em streaming, voz, Chromecast/Cast, Miracast ou atualizações, decida quais usa e mantenha esses apps ativos.
5. Desative somente um pacote por vez; verifique lista de desativados e funções da TV. Aguarde pelo menos 15 segundos antes de reiniciar.
6. Teste Home, HDMI, Live TV/tuner, teclado, controle remoto, Bluetooth, Wi‑Fi, Play Store, Play Services e streaming.
7. Reative qualquer pacote que cause regressão. Ao terminar, desligue Wireless debugging/ADB na TV e revogue autorizações de depuração.

## Privacidade

O app não tem backend nem analytics. O tráfego é direcionado ao IP/porta informados. Arquivos de backup ficam no diretório privado do app. Nesta versão, a exportação/compartilhamento externo do ZIP ainda não foi implementada; não desinstale o app antes de preservar o backup por outro meio.

## Licença

Código deste projeto: MIT. A biblioteca Kadb é dependência de terceiros sob Apache-2.0; consulte o repositório do fornecedor antes de redistribuir.


## Compilar sem computador
Consulte `docs/COMPILAR_PELO_CELULAR.md`. O workflow `.github/workflows/build-apk.yml` compila o APK no GitHub Actions e publica o APK debug como Artifact.
