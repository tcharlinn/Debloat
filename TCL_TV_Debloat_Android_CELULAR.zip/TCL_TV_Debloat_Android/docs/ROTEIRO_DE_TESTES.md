# Roteiro de testes em TV real

- [ ] TV identificada como Android TV/Google TV (não Roku, webOS, Tizen, VIDAA ou SmartCast).
- [ ] Telefone e TV na mesma LAN; sem isolamento de clientes no roteador.
- [ ] Pareamento Wireless Debugging concluído ou TCP ADB legado autorizado.
- [ ] Diagnóstico salvo e conferido: modelo, versão, SDK, build, rede e resolução.
- [ ] Backup ZIP copiado para fora do app.
- [ ] Lista de pacotes revisada; nomes ambíguos inspecionados com `dumpsys package`.
- [ ] USBs conectados identificados; verificar separadamente se USB-Ethernet fornece a rede.
- [ ] Um pacote candidato desativado; `pm list packages -d` confirma o estado.
- [ ] Aguardar 15 segundos e `sync` antes de reboot.
- [ ] Reiniciar uma vez e confirmar persistência/auto reativação pelo firmware.
- [ ] Testar Home, HDMI, tuner/Live TV, controle, Bluetooth, teclado, Wi‑Fi, Play Store/Services e apps de streaming.
- [ ] Restaurar pacote caso qualquer função falhe.
- [ ] Desligar ADB/Wireless debugging e revogar autorizações.

Faça capturas de tela da TV manualmente entre as etapas nesta versão; captura/pull automático ainda não está incluído.
