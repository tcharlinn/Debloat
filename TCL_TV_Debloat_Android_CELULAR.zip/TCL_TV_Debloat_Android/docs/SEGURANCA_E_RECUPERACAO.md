# Segurança e recuperação

## Não executar em lote

Este aplicativo deliberadamente não oferece “debloat com um clique”. Faça uma alteração por vez e confira o resultado na própria TV. A família `com.android.*`, `com.google.android.*`, `com.android.providers.*`, `android`, SystemUI, Settings, TV Settings, shell, phone, permission controller, package installer e Play services devem ser tratadas como críticas. A proteção do código é apenas uma barreira adicional, não uma garantia.

## Backup

O ZIP contém saídas de comandos de leitura: `pm list packages`, `getprop`, `settings list global/secure/system`, `dumpsys wifi` e `dumpsys connectivity`. Não contém firmware, dados de apps, chaves Wi‑Fi exportáveis nem uma imagem completa do sistema.

## Restaurar

Use “Restaurar alterações do último backup” no app para reativar os pacotes que ele registrou como desativados. Se a TV perder o ADB, volte às configurações da TV com o controle remoto, habilite ADB e reconecte; ou use o projeto Windows/ADB em computador. Se a interface Home ficar preta, reative primeiro o launcher original identificado no diagnóstico. Não desative o launcher de fábrica sem instalar, definir e testar um launcher alternativo e sem ter um caminho de retorno.

## Rede e segurança

ADB TCP clássico na porta 5555 não é criptografado em todos os firmwares. Não deixe ADB aberto na rede depois do trabalho. Desative depuração sem fio/ADB, revogue autorizações e reinicie a TV. Se a rede da TV vier por adaptador USB-Ethernet, não remova nem altere o adaptador durante a sessão.
