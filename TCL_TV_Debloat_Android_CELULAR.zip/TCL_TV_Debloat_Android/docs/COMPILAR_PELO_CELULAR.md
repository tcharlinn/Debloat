# Gerar o APK usando somente o smartphone

Este projeto contém o código-fonte Android. O APK não vem pré-compilado nem foi validado em TV física. Para gerar o APK sem computador, use o GitHub Actions no navegador do próprio celular:

1. Extraia o ZIP com um gerenciador de arquivos Android.
2. No navegador do celular, crie um repositório novo no GitHub.
3. Envie **o conteúdo da pasta `TCL_TV_Debloat_Android`** para a raiz do repositório (incluindo `.github`; habilite mostrar arquivos ocultos se necessário).
4. Abra a aba **Actions** do repositório. Se solicitado, habilite GitHub Actions.
5. Execute **Build Android APK** com **Run workflow**, ou aguarde o build disparar após enviar os arquivos para `main`.
6. Abra a execução concluída, entre em **Artifacts** e baixe `TCL-TV-Debloat-debug-apk`.
7. Extraia o APK no celular e instale. O Android pode pedir autorização para instalar apps dessa origem.

O build na nuvem requer uma conta GitHub. Não publique backups da TV no repositório.

## Importante
- Esta automação compila o projeto; não significa que o app foi compilado/testado nesta conversa.
- A implementação usa ADB por Wi-Fi e exige que a TV ofereça ADB TCP ou Wireless debugging compatível.
- A primeira conexão pode exigir pareamento e confirmação na tela da TV.
- O backup é inventário/configurações consultáveis, não imagem completa do firmware.
- Não desative pacotes desconhecidos ou essenciais. Desligue ADB/Wireless debugging ao terminar.
- O launcher Apple TV ainda não faz parte desta versão. A versão atual é o controlador/gerenciador TCL TV Debloat.
