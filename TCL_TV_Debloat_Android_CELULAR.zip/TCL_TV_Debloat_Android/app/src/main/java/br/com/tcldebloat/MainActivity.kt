package br.com.tcldebloat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import android.app.AlertDialog
import kotlinx.coroutines.*
import com.flyfishxu.kadb.Kadb
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var host = ""
    private var port = 5555
    private var connected = false
    private lateinit var logView: TextView
    private lateinit var ipField: EditText
    private lateinit var portField: EditText
    private lateinit var packageField: EditText
    private lateinit var pairPortField: EditText
    private lateinit var pairCodeField: EditText
    private lateinit var statusView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 11, 18)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 22, 22, 22); setBackgroundColor(Color.rgb(8,11,18)) }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.layoutParams = ViewGroup.LayoutParams(-1, -1)
        val title = TextView(this).apply { text = "TCL TV DEBLOAT"; textSize = 25f; setTextColor(Color.WHITE); setPadding(0,0,0,8) }
        body.addView(title)
        body.addView(label("Gerencie sua TV TCL por ADB via Wi-Fi"))
        statusView = label("● Desconectado — mesma rede Wi-Fi necessária")
        statusView.setTextColor(Color.rgb(255,190,90)); body.addView(statusView)
        ipField = edit("IP da TV (ex.: 192.168.1.50)")
        portField = edit("Porta ADB (padrão 5555)", "5555")
        body.addView(ipField); body.addView(portField)
        body.addView(button("Conectar por ADB TCP", Color.rgb(37,99,235)) { connect() })
        body.addView(label("Android 11+ / Google TV: primeiro pare usando o código de pareamento"))
        pairPortField = edit("Porta de pareamento (Wireless debugging)")
        pairCodeField = edit("Código de 6 dígitos", "", true)
        body.addView(pairPortField); body.addView(pairCodeField)
        body.addView(button("Parear e conectar (TLS)", Color.rgb(30,120,95)) { pair() })
        body.addView(section("DIAGNÓSTICO E BACKUP"))
        body.addView(button("Executar diagnóstico", Color.rgb(47,55,72)) { runDiagnostic() })
        body.addView(button("Criar backup completo", Color.rgb(47,55,72)) { createBackup() })
        body.addView(button("Listar aplicativos instalados", Color.rgb(47,55,72)) { listPackages() })
        body.addView(button("Capturar screenshot da TV", Color.rgb(47,55,72)) { captureScreenshot() })
        body.addView(section("DEBLOAT COM PROTEÇÃO"))
        packageField = edit("Nome exato do pacote (com.exemplo.app)")
        body.addView(packageField)
        body.addView(button("Analisar pacote (dumpsys)", Color.rgb(47,55,72)) { inspectPackage() })
        body.addView(button("Desativar pacote (com confirmação)", Color.rgb(160,75,35)) { confirmDisable() })
        body.addView(button("Reativar pacote", Color.rgb(47,110,75)) { enablePackage() })
        body.addView(button("Restaurar alterações do último backup", Color.rgb(110,75,150)) { restoreFromBackup() })
        body.addView(section("REGISTRO"))
        logView = TextView(this).apply { text = "Pronto. Conecte-se à TV para começar.\n"; textSize = 12f; setTextColor(Color.rgb(205,215,230)); setPadding(12,12,12,12); setBackgroundColor(Color.rgb(18,23,34)) }
        body.addView(logView)
        setContentView(root)
    }

    private fun label(s: String) = TextView(this).apply { text=s; textSize=13f; setTextColor(Color.LTGRAY); setPadding(0,8,0,8) }
    private fun section(s: String) = TextView(this).apply { text=s; textSize=14f; setTextColor(Color.rgb(115,165,255)); setPadding(0,20,0,8) }
    private fun edit(hint: String, value: String = "", password: Boolean = false) = EditText(this).apply {
        setSingleLine(true); this.hint=hint; setText(value); textSize=14f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        inputType = if (password) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        setPadding(12,8,12,8); setBackgroundColor(Color.rgb(24,31,45));
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=8; layoutParams=lp
    }
    private fun button(s:String, color:Int, action:()->Unit) = Button(this).apply {
        text=s; isAllCaps=false; setTextColor(Color.WHITE); setBackgroundColor(color); setOnClickListener { action() }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=7; layoutParams=lp
    }
    private fun log(s: String) { logView.append("\n$s"); }
    private fun requireConnection(): Boolean { if (!connected) { log("Conecte-se à TV primeiro."); return false }; return true }

    private fun connect() {
        host=ipField.text.toString().trim(); port=portField.text.toString().toIntOrNull() ?: 5555
        if (host.isBlank()) { log("Informe o IP da TV."); return }
        scope.launch {
            try { val r=withContext(Dispatchers.IO) { Kadb.create(host,port).use { it.shell("getprop ro.product.model").output } }
                connected=true; statusView.text="● Conectado: $host:$port"; statusView.setTextColor(Color.GREEN); log("Conexão ADB estabelecida. Modelo: ${r.trim()}")
            } catch(e:Exception) { connected=false; log("Falha ao conectar: ${e.message}\nConfira IP/porta, Wi-Fi e depuração ADB na TV.") }
        }
    }
    private fun pair() {
        host=ipField.text.toString().trim(); val pp=pairPortField.text.toString().toIntOrNull(); val code=pairCodeField.text.toString().trim()
        if(host.isBlank() || pp==null || code.length!=6) { log("Informe IP, porta de pareamento e código de 6 dígitos."); return }
        scope.launch { try {
            withContext(Dispatchers.IO) { Kadb.pair(host,pp,code) }
            log("Pareamento TLS concluído. Agora informe na porta ADB principal exibida em Wireless debugging e toque em Conectar por ADB TCP.")
        } catch(e:Exception) { log("Falha no pareamento: ${e.message}") } }
    }
    private suspend fun shell(command:String):String = withContext(Dispatchers.IO) { Kadb.create(host,port).use { it.shell(command).output } }
    private fun runDiagnostic() { if(!requireConnection()) return; scope.launch { try {
        val cmds=listOf("getprop ro.product.manufacturer","getprop ro.product.model","getprop ro.product.device","getprop ro.build.version.release","getprop ro.build.version.sdk","getprop ro.build.fingerprint","getprop ro.build.version.security_patch","wm size","wm density","dumpsys meminfo | head -n 20","dumpsys connectivity | grep -E 'Transports:|NetworkAgentInfo' | head -n 12","dumpsys usb | grep host_connected","pm list packages -d")
        val names=listOf("Fabricante","Modelo","Dispositivo","Android","SDK","Build fingerprint","Patch de segurança","Resolução","Densidade","Memória","Rede","USB host","Pacotes desativados")
        val out=StringBuilder("DIAGNÓSTICO TCL TV\n")
        cmds.forEachIndexed { i,c -> out.append("\n${names[i]}:\n${shell(c)}\n") }
        saveText("diagnostico.txt",out.toString()); log("Diagnóstico concluído e salvo em ${filesDir}/backups/diagnostico.txt\n${out}")
    } catch(e:Exception){ log("Erro no diagnóstico: ${e.message}") } } }
    private fun createBackup() { if(!requireConnection()) return; scope.launch { try {
        val commands=linkedMapOf("packages-all.txt" to "pm list packages","packages-third-party.txt" to "pm list packages -3","packages-disabled.txt" to "pm list packages -d","getprop.txt" to "getprop","settings-global.txt" to "settings list global","settings-secure.txt" to "settings list secure","settings-system.txt" to "settings list system","wifi.txt" to "dumpsys wifi | head -n 200","connectivity.txt" to "dumpsys connectivity | head -n 200")
        val folder=File(filesDir,"backups/${System.currentTimeMillis()}").apply{mkdirs()}
        for((name,cmd) in commands) File(folder,name).writeText(shell(cmd))
        File(folder,"README-RESTORE.txt").writeText("Backup de inventário e configurações ADB. Não é imagem de firmware nem backup de dados pessoais.\nPacotes desativados antes da alteração: packages-disabled.txt\n")
        val zip=File(filesDir,"TCL-backup-${System.currentTimeMillis()}.zip"); zipFolder(folder,zip)
        log("Backup criado: ${zip.absolutePath}\nCopie/compartilhe o ZIP pelo gerenciador de arquivos do Android.")
    } catch(e:Exception){ log("Falha no backup: ${e.message}") } } }
    private fun captureScreenshot() { if(!requireConnection()) return; scope.launch { try {
        val remote="/sdcard/tcl-debloat-${System.currentTimeMillis()}.png"
        shell("screencap -p $remote")
        val local=File(filesDir,"screenshots/${System.currentTimeMillis()}.png"); local.parentFile?.mkdirs()
        withContext(Dispatchers.IO) { Kadb.create(host,port).use { it.pull(local,remote); it.shell("rm -f $remote") } }
        log("Screenshot puxado da TV: ${local.absolutePath}")
    } catch(e:Exception){ log("Screenshot indisponível neste firmware ou falha ADB: ${e.message}") } } }
    private fun listPackages() { if(!requireConnection()) return; scope.launch { try {
        val all=shell("pm list packages"); val disabled=shell("pm list packages -d"); val d=disabled.lines().map{it.substringAfter("package:").trim()}.filter{it.isNotBlank()}.toSet()
        val lines=all.lines().map{it.substringAfter("package:").trim()}.filter{it.isNotBlank()}.sorted()
        val result=lines.joinToString("\n"){p -> "${if(p in d) "[DESATIVADO]" else "[ATIVO]"} $p  |  ${classify(p)}"}
        saveText("pacotes-classificados.txt",result); log("${lines.size} pacotes listados. Resultado salvo em ${filesDir}/backups/pacotes-classificados.txt\n$result")
    } catch(e:Exception){ log("Erro listando pacotes: ${e.message}") } } }
    private fun classify(p:String):String { val s=p.lowercase(); return when {
        s.startsWith("com.android.") || s.startsWith("com.google.android.") || s=="android" -> "PROTEGIDO / SISTEMA — não desativar"
        listOf("analytics","telemetry","tracking","adservice","ads","recommend","patchwall").any{s.contains(it)} -> "Possível telemetria/conteúdo/anúncios — investigar"
        listOf("netflix","youtube","primevideo","disney","spotify","globoplay").any{s.contains(it)} -> "Streaming — perguntar ao usuário"
        else -> "Aplicativo — investigar com dumpsys"
    } }
    private fun inspectPackage() { if(!requireConnection()) return; val p=packageField.text.toString().trim(); if(p.isBlank()) return
        scope.launch { try { val out=shell("dumpsys package $p"); saveText("package-$p.txt",out); log("Detalhes de $p salvos. Não iniciamos atividades de fábrica/fac/AT.") } catch(e:Exception){ log("Falha ao inspecionar: ${e.message}") } }
    }
    private val protectedPrefixes=listOf("com.android.","com.google.android.")
    private val protectedExact=setOf("android","com.android.systemui","com.android.shell","com.android.phone","com.android.settings","com.android.tv.settings","com.google.android.gms","com.android.permissioncontroller","com.google.android.packageinstaller","com.android.providers.settings","com.google.android.overlay.modules")
    private fun isProtected(p:String)=p in protectedExact || p=="android" || protectedPrefixes.any{p.startsWith(it)} || p.startsWith("com.google.android.overlay.modules") || p.startsWith("com.android.providers.")
    private fun confirmDisable() { if(!requireConnection()) return; val p=packageField.text.toString().trim(); if(p.isBlank()) return
        if(isProtected(p)){ log("BLOQUEADO: $p pertence a uma família protegida do Android/Google. Não será desativado."); return }
        AlertDialog.Builder(this).setTitle("Confirmar desativação").setMessage("Desativar $p para o usuário 0?\n\nIsso pode remover funções da TV. O app exige confirmação individual e recomenda analisar dumpsys primeiro.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Desativar"){_,_-> disable(p) }.show()
    }
    private fun disable(p:String) { scope.launch { try {
        val before=shell("pm list packages -d"); val result=shell("pm disable-user --user 0 $p"); delay(15000); shell("sync"); val after=shell("pm list packages -d")
        val actually=after.contains("package:$p"); if(actually) { val f=File(filesDir,"backups/disabled-by-this-app.txt"); f.parentFile?.mkdirs(); f.appendText("$p\n") }
        log("Comando: $result\nVerificação: ${if(actually) "pacote aparece na lista de desativados" else "não foi confirmado na lista pm list packages -d"}. Estado anterior registrado? ${before.contains("package:$p")}")
    } catch(e:Exception){ log("Falha ao desativar: ${e.message}") } } }
    private fun enablePackage() { if(!requireConnection()) return; val p=packageField.text.toString().trim(); if(p.isBlank()) return
        scope.launch { try { val r=shell("pm enable --user 0 $p"); log("Reativação solicitada para $p: $r") } catch(e:Exception){log("Falha ao reativar: ${e.message}")} }
    }
    private fun restoreFromBackup() { if(!requireConnection()) return
        val f=File(filesDir,"backups/disabled-by-this-app.txt"); if(!f.exists()){ log("Não há registro local de pacotes desativados por este app."); return }
        AlertDialog.Builder(this).setTitle("Restaurar alterações").setMessage("Reativar todos os pacotes registrados por este app? A lista é local a este telefone.")
            .setNegativeButton("Cancelar",null).setPositiveButton("Restaurar"){_,_-> scope.launch { try {
                val pkgs=f.readLines().map{it.trim()}.filter{it.isNotBlank()}.distinct(); pkgs.forEach { p -> if(!isProtected(p)) { shell("pm enable --user 0 $p"); log("Reativado: $p") } }
                log("Restauração concluída. Reinicie a TV e confira Home, HDMI, Live TV, controle e Wi-Fi.")
            } catch(e:Exception){log("Falha na restauração: ${e.message}")} } }.show()
    }
    private fun saveText(name:String, text:String) { val dir=File(filesDir,"backups").apply{mkdirs()}; File(dir,name).writeText(text) }
    private fun zipFolder(folder:File, zip:File) { ZipOutputStream(FileOutputStream(zip)).use { zos -> folder.walkTopDown().filter{it.isFile}.forEach { f -> zos.putNextEntry(ZipEntry(f.relativeTo(folder).path)); f.inputStream().use{it.copyTo(zos)}; zos.closeEntry() } } }
    override fun onDestroy(){ super.onDestroy(); scope.cancel() }
}
